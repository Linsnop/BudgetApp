package com.itesm.budget.ui.gallery

data class RegistroGasto(var categoria: String="",
                         var gasto: Double = 0.0)
